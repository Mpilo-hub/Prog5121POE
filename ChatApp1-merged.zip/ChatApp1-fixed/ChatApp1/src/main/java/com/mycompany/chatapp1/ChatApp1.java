package com.mycompany.chatapp1;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * QuickChat: registration, login, then sending messages.
 */
public class ChatApp1 {

    static final String JSON_FILE = "storedMessages.json";

    /** All messages (sent, stored, disregarded) for this run. */
    private static MessageManager manager = new MessageManager();

    // Dialog hooks: default to Swing dialogs, replaceable so the flow can be driven by tests.
    static Function<String, String> asker = p -> JOptionPane.showInputDialog(null, p);
    static Consumer<String> shower = t -> JOptionPane.showMessageDialog(null, t);

    /** Resets state (used by tests). */
    static void resetForTests() {
        manager = new MessageManager();
    }

    public static void main(String[] args) {
        Login login = register();
        if (login == null) {
            return;
        }
        if (!login(login)) {
            return;
        }
        chat(login);
    }

    // ---------- Part 1 ----------
    private static Login register() {
        show("=== QuickChat Registration ===");
        String first = ask("Enter First Name:");
        if (first == null) return null;
        String last = ask("Enter Last Name:");
        if (last == null) return null;
        Login login = new Login(first, last);

        String username;
        do {
            username = ask("Enter Username (must contain '_' and be at most 5 characters):");
            if (username == null) return null;
            show(login.usernameMessage(username));
        } while (!login.checkUserName(username));

        String password;
        do {
            password = ask("Enter Password (8+ characters, capital, number, special character):");
            if (password == null) return null;
            show(login.passwordMessage(password));
        } while (!login.checkPasswordComplexity(password));

        String cell;
        do {
            cell = ask("Enter Cell Number with international code (e.g. +27838968976):");
            if (cell == null) return null;
            show(login.cellMessage(cell));
        } while (!login.checkCellPhoneNumber(cell));

        show(login.registerUser(username, password, cell));
        return login;
    }

    private static boolean login(Login login) {
        show("=== QuickChat Login ===");
        while (true) {
            String u = ask("Enter Username:");
            if (u == null) return false;
            String p = ask("Enter Password:");
            if (p == null) return false;
            boolean ok = login.loginUser(u, p);
            show(login.returnLoginStatus(ok));
            if (ok) return true;
        }
    }

    // ---------- Parts 2 and 3 ----------
    private static void chat(Login login) {
        show("Welcome to QuickChat.");
        loadStoredMessages();

        Integer max = null;
        while (max == null) {
            String s = ask("How many messages do you wish to enter?");
            if (s == null) return;
            try {
                int n = Integer.parseInt(s.trim());
                if (n > 0) max = n;
            } catch (NumberFormatException ignored) {
                // ask again
            }
        }

        int entered = 0;
        boolean running = true;
        while (running) {
            String choice = ask("MAIN MENU\n1) Send Messages\n2) Show recently sent messages\n3) Quit\n4) Stored Messages\n\nChoose an option:");
            if (choice == null) break;
            switch (choice.trim()) {
                case "1":
                    if (entered >= max) {
                        show("You have already entered all " + max + " messages.");
                    } else {
                        entered = sendMessages(login, entered, max);
                    }
                    break;
                case "2":
                    String sent = manager.report(MessageManager.SENT);
                    show(sent.isEmpty() ? "No messages have been sent yet." : sent);
                    break;
                case "3":
                    running = false;
                    break;
                case "4":
                    storedMenu();
                    break;
                default:
                    show("Please choose 1, 2, 3 or 4.");
            }
        }
        show("Total messages sent: " + Message.returnTotalMessages());
    }

    /** Loads previously stored messages from the JSON file, if it exists. */
    private static void loadStoredMessages() {
        if (!new File(JSON_FILE).exists()) {
            return;
        }
        try {
            int n = JsonStorage.loadStored(manager, JSON_FILE);
            show(n + " stored message(s) loaded from " + JSON_FILE);
        } catch (IOException | RuntimeException e) {
            show("Could not read " + JSON_FILE + ": " + e.getMessage());
        }
    }

    private static void saveStoredMessages() {
        try {
            JsonStorage.saveStored(manager, JSON_FILE);
        } catch (IOException e) {
            show("Could not save to " + JSON_FILE + ": " + e.getMessage());
        }
    }

    /** Captures messages until the limit is reached; returns how many have been entered in total. */
    private static int sendMessages(Login login, int entered, int max) {
        String sender = login.getCellNumber() == null ? "" : login.getCellNumber();
        while (entered < max) {
            String recipient;
            while (true) {
                recipient = ask("Message " + (entered + 1) + " of " + max + "\nRecipient cell number (e.g. +27718693002):");
                if (recipient == null) return entered;
                String r = new Message(0, recipient, "x").checkRecipientCell();
                show(r);
                if (r.startsWith("Cell phone number successfully")) break;
            }

            String text;
            while (true) {
                text = ask("Enter your message (max 250 characters):");
                if (text == null) return entered;
                if (text.isBlank()) {
                    show("Message cannot be empty.");
                } else if (text.length() <= 250) {
                    show("Message ready to send.");
                    break;
                } else {
                    show("Message exceeds 250 characters by " + (text.length() - 250) + "; please reduce the size.");
                }
            }

            Message m = new Message(Message.returnTotalMessages(), recipient, text);
            show(m.messageIDStatus());

            int action = 0;
            while (action < 1 || action > 3) {
                String a = ask("Select an option:\n1) Send Message\n2) Disregard Message\n3) Store Message to send later");
                if (a == null) { action = 2; break; }
                try { action = Integer.parseInt(a.trim()); } catch (NumberFormatException e) { action = 0; }
            }

            String flag = action == 1 ? MessageManager.SENT
                    : action == 3 ? MessageManager.STORED : MessageManager.DISREGARD;
            String hash = manager.addMessage(m.getMessageID(), sender, recipient, text, flag);

            if (action == 2) {
                String zero;
                do {
                    zero = ask(m.SentMessage(2));
                } while (zero != null && !zero.trim().equals("0"));
                show("Message deleted.");
            } else if (action == 1) {
                show(m.SentMessage(1));
                show("Message ID: " + m.getMessageID() + "\nMessage Hash: " + hash
                        + "\nRecipient: " + recipient + "\nMessage: " + text);
            } else {
                saveStoredMessages();
                show("Message successfully stored.\nMessage ID: " + m.getMessageID() + "\nMessage Hash: " + hash);
            }
            entered++;
        }
        return entered;
    }

    private static void storedMenu() {
        boolean back = false;
        while (!back) {
            String c = ask("STORED MESSAGES\n"
                    + "a) Display sender and recipient of all stored messages\n"
                    + "b) Display the longest stored message\n"
                    + "c) Search for a message ID\n"
                    + "d) Search all messages stored for a recipient\n"
                    + "e) Delete a message using its hash\n"
                    + "f) Display report of all stored messages\n"
                    + "g) Back\n\nChoose:");
            if (c == null) return;
            switch (c.trim().toLowerCase()) {
                case "a":
                    show(orNothing(manager.senderAndRecipientReport(MessageManager.STORED), "No stored messages."));
                    break;
                case "b":
                    String longest = manager.longestMessage(MessageManager.STORED);
                    show(longest == null ? "No stored messages." : longest);
                    break;
                case "c":
                    String id = ask("Enter message ID:");
                    if (id != null) {
                        String r = manager.searchByIdDetails(id.trim());
                        show(r == null ? "Message ID not found." : r);
                    }
                    break;
                case "d":
                    String rec = ask("Enter recipient number:");
                    if (rec != null) {
                        ArrayList<String> found = manager.searchByRecipient(rec.trim());
                        show(found.isEmpty() ? "No messages for that recipient." : String.join("\n", found));
                    }
                    break;
                case "e":
                    String hash = ask("Enter message hash:");
                    if (hash != null) {
                        show(manager.deleteByHash(hash.trim().toUpperCase()));
                        saveStoredMessages();
                    }
                    break;
                case "f":
                    show(orNothing(manager.report(MessageManager.STORED), "No stored messages."));
                    break;
                case "g":
                    back = true;
                    break;
                default:
                    show("Invalid option.");
            }
        }
    }

    private static String orNothing(String s, String fallback) {
        return s.isEmpty() ? fallback : s;
    }

    private static String ask(String prompt) {
        return asker.apply(prompt);
    }

    private static void show(String text) {
        shower.accept(text);
    }
}
