package com.mycompany.chatapp1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/** Reads and writes the stored messages JSON file using Gson. */
public class JsonStorage {

    /** Simple data holder that Gson converts to and from JSON. */
    public static class StoredMessage {
        public String messageId;
        public String messageHash;
        public String sender;
        public String recipient;
        public String message;
        public String flag;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Writes every message flagged "Stored" to the JSON file. */
    public static void saveStored(MessageManager m, String path) throws IOException {
        List<StoredMessage> list = new ArrayList<>();
        for (int i = 0; i < m.texts.size(); i++) {
            if (m.flags.get(i).equalsIgnoreCase(MessageManager.STORED)) {
                StoredMessage s = new StoredMessage();
                s.messageId = m.messageIds.get(i);
                s.messageHash = m.messageHashes.get(i);
                s.sender = m.senders.get(i);
                s.recipient = m.recipients.get(i);
                s.message = m.texts.get(i);
                s.flag = m.flags.get(i);
                list.add(s);
            }
        }
        try (FileWriter w = new FileWriter(path)) {
            GSON.toJson(list, w);
        }
    }

    /** Reads the JSON file into the manager's arrays (no hard-coding). Returns how many were loaded. */
    public static int loadStored(MessageManager m, String path) throws IOException {
        Type type = new TypeToken<List<StoredMessage>>() { }.getType();
        List<StoredMessage> list;
        try (FileReader r = new FileReader(path)) {
            list = GSON.fromJson(r, type);
        }
        if (list == null) {
            return 0;
        }
        int count = 0;
        for (StoredMessage s : list) {
            if (s == null || s.messageId == null || s.message == null || s.message.isBlank()) {
                continue; // skip malformed entries
            }
            if (s.sender == null) {
                s.sender = "";
            }
            if (s.recipient == null) {
                s.recipient = "";
            }
            if (m.findIndexById(s.messageId) == -1) {
                m.addMessage(s.messageId, s.messageHash, s.sender, s.recipient, s.message, MessageManager.STORED);
                count++;
            }
        }
        return count;
    }
}
