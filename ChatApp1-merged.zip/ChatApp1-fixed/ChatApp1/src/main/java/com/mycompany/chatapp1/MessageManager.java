package com.mycompany.chatapp1;

import java.util.ArrayList;

/**
 * Holds every array required by Part 3 and all the operations on them.
 *
 * Required arrays:
 *   sentMessages, disregardedMessages, storedMessages, messageHashes, messageIds
 *
 * The "master" parallel arrays (messageIds, messageHashes, senders, recipients,
 * texts, flags) always share the same index, so index i describes one message.
 */
public class MessageManager {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    // ---- Required arrays ----
    public ArrayList<String> sentMessages = new ArrayList<>();
    public ArrayList<String> disregardedMessages = new ArrayList<>();
    public ArrayList<String> storedMessages = new ArrayList<>();
    public ArrayList<String> messageHashes = new ArrayList<>();
    public ArrayList<String> messageIds = new ArrayList<>();

    // ---- Parallel arrays (same index = same message) ----
    public ArrayList<String> senders = new ArrayList<>();
    public ArrayList<String> recipients = new ArrayList<>();
    public ArrayList<String> texts = new ArrayList<>();
    public ArrayList<String> flags = new ArrayList<>();

    /** Running message number used in hashes; never reused, even after deletions. */
    private int counter = 0;

    /** Adds a message to the correct arrays. Returns the generated hash. */
    public String addMessage(String id, String sender, String recipient, String text, String flag) {
        return addMessage(id, null, sender, recipient, text, flag);
    }

    /** Adds a message; a non-null hash (e.g. loaded from JSON) is kept instead of generating a new one. */
    public String addMessage(String id, String existingHash, String sender, String recipient,
                             String text, String flag) {
        counter++;
        String hash = existingHash != null && !existingHash.isEmpty()
                ? existingHash : createHash(id, counter, text);

        messageIds.add(id);
        messageHashes.add(hash);
        senders.add(sender);
        recipients.add(recipient);
        texts.add(text);
        flags.add(flag);

        if (flag.equalsIgnoreCase(SENT)) {
            sentMessages.add(text);
        } else if (flag.equalsIgnoreCase(STORED)) {
            storedMessages.add(text);
        } else {
            disregardedMessages.add(text);
        }
        return hash;
    }

    /** Hash format: first two digits of ID : message number : FIRSTWORDLASTWORD (upper case). */
    public static String createHash(String id, int number, String text) {
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String prefix = id.length() >= 2 ? id.substring(0, 2) : id;
        return (prefix + ":" + number + ":" + first + last).toUpperCase();
    }

    /** Longest message. Pass a flag (e.g. "Stored") to limit the search, or null for all messages. */
    public String longestMessage(String flag) {
        String longest = null;
        for (int i = 0; i < texts.size(); i++) {
            if (flag != null && !flags.get(i).equalsIgnoreCase(flag)) {
                continue;
            }
            if (longest == null || texts.get(i).length() > longest.length()) {
                longest = texts.get(i);
            }
        }
        return longest;
    }

    /** Returns index of a message ID, or -1 if not found. */
    public int findIndexById(String id) {
        for (int i = 0; i < messageIds.size(); i++) {
            if (messageIds.get(i).equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /** Search by message ID: returns the message text, or null if not found. */
    public String searchById(String id) {
        int i = findIndexById(id);
        return i == -1 ? null : texts.get(i);
    }

    /** Search by message ID: returns recipient and message together for display. */
    public String searchByIdDetails(String id) {
        int i = findIndexById(id);
        if (i == -1) {
            return null;
        }
        return "Recipient: " + recipients.get(i) + " | Message: \"" + texts.get(i) + "\"";
    }

    /** All messages (sent or stored) for one recipient. Disregarded messages are skipped. */
    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++) {
            boolean relevant = flags.get(i).equalsIgnoreCase(SENT) || flags.get(i).equalsIgnoreCase(STORED);
            if (relevant && recipients.get(i).equals(recipient)) {
                found.add(texts.get(i));
            }
        }
        return found;
    }

    /** Deletes a message by hash from every array. Returns a confirmation or a not-found note. */
    public String deleteByHash(String hash) {
        int i = messageHashes.indexOf(hash);
        if (i == -1) {
            return "No message found with hash " + hash + ".";
        }
        String text = texts.get(i);
        String flag = flags.get(i);

        if (flag.equalsIgnoreCase(SENT)) {
            sentMessages.remove(text);
        } else if (flag.equalsIgnoreCase(STORED)) {
            storedMessages.remove(text);
        } else {
            disregardedMessages.remove(text);
        }

        messageIds.remove(i);
        messageHashes.remove(i);
        senders.remove(i);
        recipients.remove(i);
        texts.remove(i);
        flags.remove(i);

        return "Message: \"" + text + "\" successfully deleted.";
    }

    /** Sender and recipient of every message with the given flag. */
    public String senderAndRecipientReport(String flag) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < texts.size(); i++) {
            if (flags.get(i).equalsIgnoreCase(flag)) {
                sb.append("Sender: ").append(senders.get(i))
                  .append(" | Recipient: ").append(recipients.get(i)).append("\n");
            }
        }
        return sb.toString();
    }

    /** Full report (hash, ID, sender, recipient, message) for every message with the given flag. */
    public String report(String flag) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < texts.size(); i++) {
            if (flags.get(i).equalsIgnoreCase(flag)) {
                sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                  .append("Message ID:   ").append(messageIds.get(i)).append("\n")
                  .append("Sender:       ").append(senders.get(i)).append("\n")
                  .append("Recipient:    ").append(recipients.get(i)).append("\n")
                  .append("Message:      ").append(texts.get(i)).append("\n")
                  .append("-----------------------------\n");
            }
        }
        return sb.toString();
    }
}
