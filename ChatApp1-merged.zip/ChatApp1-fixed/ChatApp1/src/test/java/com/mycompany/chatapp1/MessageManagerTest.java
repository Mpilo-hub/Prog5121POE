package com.mycompany.chatapp1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/** Unit tests for Part 3, using the supplied test data (Messages 1-5). */
public class MessageManagerTest {

    private MessageManager m;

    @BeforeEach
    void setUp() {
        m = new MessageManager();
        // Test data read from the task: message 4's ID is 0838884567
        m.addMessage("0000000001", "+27000000000", "+27834557896",
                "Did you get the cake?", MessageManager.SENT);
        m.addMessage("0000000002", "+27000000000", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", MessageManager.STORED);
        m.addMessage("0000000003", "+27000000000", "+27834484567",
                "Yohoooo, I am at your gate.", MessageManager.DISREGARD);
        m.addMessage("0838884567", "Developer", "0838884567",
                "It is dinner time!", MessageManager.SENT);
        m.addMessage("0000000005", "+27000000000", "+27838884567",
                "Ok, I am leaving without you.", MessageManager.STORED);
    }

    @Test
    void sentMessagesArrayCorrectlyPopulated() {
        ArrayList<String> expected = new ArrayList<>(Arrays.asList("Did you get the cake?", "It is dinner time!"));
        assertEquals(expected, m.sentMessages);
    }

    @Test
    void displayLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.", m.longestMessage(null));
    }

    @Test
    void searchForMessageId() {
        assertEquals("It is dinner time!", m.searchById("0838884567"));
    }

    @Test
    void searchAllMessagesForRecipient() {
        ArrayList<String> expected = new ArrayList<>(Arrays.asList(
                "Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."));
        assertEquals(expected, m.searchByRecipient("+27838884567"));
    }

    @Test
    void deleteMessageUsingHash() {
        String hash = m.messageHashes.get(1); // Test Message 2
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                m.deleteByHash(hash));
        assertFalse(m.storedMessages.contains("Where are you? You are late! I have asked you to be on time."));
        assertEquals(4, m.messageIds.size());
    }

    @Test
    void displayReportShowsHashRecipientAndMessage() {
        String report = m.report(MessageManager.SENT);
        assertTrue(report.contains(m.messageHashes.get(0)));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time!"));
    }

    @Test
    void disregardedAndHashAndIdArraysPopulated() {
        assertEquals(1, m.disregardedMessages.size());
        assertEquals(5, m.messageHashes.size());
        assertEquals(5, m.messageIds.size());
    }
}
