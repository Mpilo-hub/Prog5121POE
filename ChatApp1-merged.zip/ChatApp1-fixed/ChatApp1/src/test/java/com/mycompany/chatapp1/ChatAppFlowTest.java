package com.mycompany.chatapp1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Drives the whole app (registration, login, send/store/disregard, stored menu) with scripted answers. */
public class ChatAppFlowTest {

    private final List<String> shown = new ArrayList<>();
    private final Deque<String> answers = new ArrayDeque<>();

    @BeforeEach
    void setUp() {
        new File(ChatApp1.JSON_FILE).delete();
        Message.reset();
        ChatApp1.resetForTests();
        ChatApp1.asker = p -> answers.isEmpty() ? null : answers.poll();
        ChatApp1.shower = shown::add;
    }

    @AfterEach
    void tearDown() {
        new File(ChatApp1.JSON_FILE).delete();
        new File(Message.STORE_FILE).delete();
    }

    private void script(String... a) {
        answers.addAll(Arrays.asList(a));
    }

    private String allShown() {
        return String.join("\n---\n", shown);
    }

    @Test
    void fullFlowSendStoreDisregardAndStoredMenu() throws Exception {
        script("Ada", "Lovelace", "ab_c", "Passw0rd!", "+27838968976",   // register
                "ab_c", "Passw0rd!",                                       // login
                "3",                                                       // max messages
                "1",                                                       // send
                "+27834557896", "Did you get the cake?", "1",              // sent
                "+27838884567", "Where are you? You are late! I have asked you to be on time.", "3", // stored
                "+27834484567", "Yohoooo, I am at your gate.", "2", "0",   // disregarded
                "2",                                                       // show sent
                "4", "a", "b", "c", "BADID", "d", "+27838884567", "f", "g",// stored menu
                "3");                                                      // quit
        ChatApp1.main(new String[0]);
        String out = allShown();
        assertTrue(out.contains("User has been registered successfully."), out);
        assertTrue(out.contains("Message successfully sent."), out);
        assertTrue(out.contains("Message successfully stored."), out);
        assertTrue(out.contains("Message deleted."), out);
        assertTrue(out.contains("Did you get the cake?"), out);
        assertTrue(out.contains("Sender: +27838968976 | Recipient: +27838884567"), out);
        assertTrue(out.contains("Message ID not found."), out);
        assertTrue(out.contains("Total messages sent: 1"), out);

        String json = Files.readString(Path.of(ChatApp1.JSON_FILE));
        assertTrue(json.contains("Where are you?"));
        assertFalse(json.contains("Did you get the cake?"));
    }

    @Test
    void storedMessagesReloadAndDeleteByHash() throws Exception {
        MessageManager seed = new MessageManager();
        String hash = seed.addMessage("1234567890", "+27111111111", "+27222222222", "Hello there friend", MessageManager.STORED);
        JsonStorage.saveStored(seed, ChatApp1.JSON_FILE);

        script("Ada", "Lovelace", "ab_c", "Passw0rd!", "+27838968976",
                "ab_c", "Passw0rd!", "1",
                "4", "e", hash, "f", "g", "3");
        ChatApp1.main(new String[0]);
        String out = allShown();
        assertTrue(out.contains("1 stored message(s) loaded"), out);
        assertTrue(out.contains("successfully deleted."), out);
        assertTrue(out.contains("No stored messages."), out);
        assertEquals("[]", Files.readString(Path.of(ChatApp1.JSON_FILE)).replaceAll("\\s", ""));
    }
}
