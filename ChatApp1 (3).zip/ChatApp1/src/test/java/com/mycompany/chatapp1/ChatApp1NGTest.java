/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.chatapp1;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author Student
 */
public class ChatApp1NGTest {
    
    public ChatApp1NGTest() {
    }

    /**
     * Test of main method, of class ChatApp1.
     */
    @Test
    public void testMain() {
    }
    
}
