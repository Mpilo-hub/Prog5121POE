/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class ChatApp1Test {
    
    public ChatApp1Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class ChatApp1.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ChatApp1.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    public class ChatApp {

    @Test
    public void testMessageLengthSuccess() {
        ChatApp msg = new ChatApp(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        StringBuilder longText = new StringBuilder();
        for (int i = 0; i < 260; i++) longText.append("a");
        ChatApp msg = new ChatApp(0, "+27718693002", longText.toString());
        assertTrue(msg.checkMessageLength().contains("exceeds 250 characters"));
    }
    @Test
    public void testRecipientCellSuccess() {
        ChatApp msg = new ChatApp(0, "+27718693002", "Test");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testRecipientCellFailure() {
        ChatApp msg = new ChatApp(0, "08575975889", "Test");
        assertTrue(msg.checkRecipientCell().contains("incorrectly formatted"));
    }

    @Test
    public void testMessageHashFormat() {
        ChatApp msg = new ChatApp(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        msg.setMessageID("0012345678");
        String hash = msg.createMessageHash();
        assertEquals("00:0:HITONIGHT", hash);
    }
}

}
