/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    public LoginTest() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
    }

    /**
     * Test of checkCellPhoneNumber method, of class Login.
     */
    @Test
    public void testCheckCellPhoneNumber() {
    }
    private final Login login = new Login("Kyle", "Smith");

    @Test
    public void testCheckUserName() {
        // Correct format (contains '_' and <= 5 characters)
        assertTrue(login.checkUserName("kyl_1"));
        
        // Incorrect format
        assertFalse(login.checkUserName("kyle!!!!!!!"));
        assertFalse(login.checkUserName("kyle1"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        // Correct format (>= 8 chars, uppercase, digit, special character)
        assertTrue(login.checkPasswordComplexity("Ch3ccksec!"));
        
        // Incorrect format
        assertFalse(login.checkPasswordComplexity("password"));
        assertFalse(login.checkPasswordComplexity("Short1!"));
    }

    @Test
    public void testCheckCellPhoneNumber() {
        // Correct format (10 digits starting with 0)
        assertTrue(login.checkCellPhoneNumber("0831234567"));
        
        // Incorrect format
        assertFalse(login.checkCellPhoneNumber("12345"));
        assertFalse(login.checkCellPhoneNumber("abcdefghij"));
    }

    @Test
    public void testRegisterUser() {
        String result = login.registerUser("kyl_1", "Ch3ccksec!", "0831234567");
        assertEquals("Username successfully captured. Password successfully captured. Cell number successfully captured.", result);
    }

    @Test
    public void testLoginUserSuccess() {
        login.registerUser("kyl_1", "Ch3ccksec!", "0831234567");
        assertTrue(login.loginUser("kyl_1", "Ch3ccksec!"));
    }

    @Test
    public void testLoginUserFailure() {
        login.registerUser("kyl_1", "Ch3ccksec!", "0831234567");
        assertFalse(login.loginUser("kyl_1", "wrongpassword"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        String status = login.returnLoginStatus(true);
        assertEquals("Welcome Kyle, Smith it is great to see you again.", status);
    }

    @Test
    public void testReturnLoginStatusFailure() {
        String status = login.returnLoginStatus(false);
        assertEquals("Username or password incorrect, please try again.", status);
    }
}
}
