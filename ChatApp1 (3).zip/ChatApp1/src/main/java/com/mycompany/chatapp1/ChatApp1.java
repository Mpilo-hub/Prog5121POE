
package com.mycompany.chatapp1;
import java.util.Scanner; 

public class ChatApp1 {
    public static void main(String[]args){
    public class Login {
    private String registeredUsername;
    private String registeredPassword;
    private String registeredCellNumber;
    private String firstName;
    private String lastName;

    public Login() {}

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Validates that username contains '_' and is <= 5 characters
    public boolean checkUserName(String username) {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    // Validates password length >= 8, uppercase, digit, and special char
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    // Validates 10-digit cell phone number format
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber == null) return false;
        return cellNumber.matches("^(\\+27|0)\\d{9}$") || (cellNumber.length() == 10 && cellNumber.matches("\\d+"));
    }

    // Registers user details if all checks pass
    public String registerUser(String username, String password, String cellNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell phone number is incorrectly formatted.";
        }

        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredCellNumber = cellNumber;
        return "Username successfully captured. Password successfully captured. Cell number successfully captured.";
    }

    // Authenticates user credentials
    public boolean loginUser(String username, String password) {
        if (this.registeredUsername == null || this.registeredPassword == null) return false;
        return this.registeredUsername.equals(username) && this.registeredPassword.equals(password);
    }

    // Returns formatted login welcome or error message
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + (firstName != null ? firstName : "Kyle") + ", " + (lastName != null ? lastName : "Smith") + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
    Fixed ChatApp.java (Main Class){}
    import java.util.Scanner;

    public class ChatApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=========================================");
        System.out.println("       WELCOME TO CHATAPP REGISTRATION   ");
        System.out.println("=========================================");

        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

        Login login = new Login(firstName, lastName);

        String username;
        do {
            System.out.print("Enter username (must contain '_' and <= 5 chars): ");
            username = input.nextLine();
            if (!login.checkUserName(username)) {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            }
        } while (!login.checkUserName(username));

        String password;
        do {
            System.out.print("Enter password (>= 8 chars, 1 upper, 1 digit, 1 special): ");
            password = input.nextLine();
            if (!login.checkPasswordComplexity(password)) {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            }
        } while (!login.checkPasswordComplexity(password));

        String cellNumber;
        do {
            System.out.print("Enter cellphone number (10 digits): ");
            cellNumber = input.nextLine();
            if (!login.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell phone number is incorrectly formatted.");
            }
        } while (!login.checkCellPhoneNumber(cellNumber));

        // Registration Confirmation
        String regStatus = login.registerUser(username, password, cellNumber);
        System.out.println("\n" + regStatus);

       
        
        //Login Section
        
        System.out.println("=============================");
        System.out.println("      CHATAPP1 LOGIN         ");
        System.out.println("=============================");
        
        
        System.out.print("Enter username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = input.nextLine();

        boolean isLoggedIn = login.loginUser(loginUsername, loginPassword);
        String loginMessage = login.returnLoginStatus(isLoggedIn);
        System.out.println(loginMessage);

        input.close();
    }
    }
}
    



/**
 * Login class handling user registration and authentication for PROG5121 Part 1.
 */

