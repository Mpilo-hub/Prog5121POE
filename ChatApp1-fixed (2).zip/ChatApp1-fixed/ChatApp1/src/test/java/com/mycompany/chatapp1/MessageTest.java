package com.mycompany.chatapp1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    private Message m1;
    private Message m2;

    @BeforeEach
    public void setUp() {
        Message.reset();
        m1 = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        m2 = new Message(1, "08575975889", "Hi Keegan, did you receive the payment?");
    }

    @Test
    public void messageLengthSuccess() {
        assertEquals("Message ready to send.", m1.checkMessageLength());
    }

    @Test
    public void messageLengthFailure() {
        Message longMsg = new Message(0, "+27718693002", "a".repeat(260));
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", longMsg.checkMessageLength());
    }

    @Test
    public void recipientCorrectlyFormatted() {
        assertEquals("Cell phone number successfully captured.", m1.checkRecipientCell());
    }

    @Test
    public void recipientIncorrectlyFormatted() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                m2.checkRecipientCell());
    }

    @Test
    public void messageHashIsCorrect() {
        assertEquals("00:0:HITONIGHT", m1.getMessageHash());
        assertEquals("00:0:HITONIGHT", m1.createMessageHash());
    }

    @Test
    public void messageIDIsCreated() {
        assertTrue(m1.checkMessageID());
        assertEquals("Message ID generated: 0012345678", m1.messageIDStatus());
        assertEquals(10, m2.getMessageID().length());
        assertTrue(m2.checkMessageID());
    }

    @Test
    public void sentMessageOptions() {
        assertEquals("Message successfully sent.", m1.SentMessage(1));
        assertEquals("Press 0 to delete the message.", m2.SentMessage(2));
        assertEquals("Message successfully stored.", m2.SentMessage(3));
    }

    @Test
    public void totalMessagesCountsOnlySent() {
        m1.SentMessage(1);
        m2.SentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
        assertTrue(Message.printMessages().contains("Hi Mike"));
        assertFalse(Message.printMessages().contains("Keegan"));
    }

    @Test
    public void jsonEscapesQuotes() {
        Message q = new Message("1234567890", 0, "+27718693002", "He said \"hi\"");
        assertTrue(q.toJson().contains("He said \\\"hi\\\""));
    }

    @Test
    public void testDataFlowTwoMessages() {
        // Test Case 1: send; Test Case 2: discard
        assertEquals("Message successfully sent.", m1.SentMessage(1));
        assertEquals("Press 0 to delete the message.", m2.SentMessage(2));
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void allMessageHashesInLoop() {
        String[][] data = {
            {"0012345678", "0", "Hi Mike, can you join us for dinner tonight?", "00:0:HITONIGHT"},
            {"0112345678", "1", "Hi Keegan, did you receive the payment?", "01:1:HIPAYMENT"},
            {"9912345678", "2", "Thanks", "99:2:THANKSTHANKS"},
            {"1234567890", "3", "Hi, thanks!", "12:3:HITHANKS"}
        };
        for (String[] d : data) {
            Message m = new Message(d[0], Integer.parseInt(d[1]), "+27718693002", d[2]);
            assertEquals(d[3], m.getMessageHash());
        }
    }

    @Test
    public void messageIDAtMostTenCharacters() {
        assertFalse(new Message("12345678901", 0, "+27718693002", "Hi there").checkMessageID());
    }
}
