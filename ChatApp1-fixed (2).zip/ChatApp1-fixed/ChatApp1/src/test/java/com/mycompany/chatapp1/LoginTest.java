package com.mycompany.chatapp1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private final Login login = new Login("Kyle", "Smith");

    // ---- assertEquals tests (messages) ----
    @Test
    public void usernameCorrectlyFormattedMessage() {
        assertEquals("Username successfully captured.", login.usernameMessage("kyl_1"));
    }

    @Test
    public void usernameIncorrectlyFormattedMessage() {
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
                login.usernameMessage("kyle!!!!!!!"));
    }

    @Test
    public void passwordMeetsComplexityMessage() {
        assertEquals("Password successfully captured.", login.passwordMessage("Ch&&sec@ke99!"));
    }

    @Test
    public void passwordDoesNotMeetComplexityMessage() {
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                login.passwordMessage("password"));
    }

    @Test
    public void cellCorrectlyFormattedMessage() {
        assertEquals("Cell number successfully captured.", login.cellMessage("+27838968976"));
    }

    @Test
    public void cellIncorrectlyFormattedMessage() {
        assertEquals("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
                login.cellMessage("08966553"));
    }

    // ---- assertTrue / assertFalse tests ----
    @Test
    public void loginSuccessful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertEquals("Welcome Kyle, Smith it is great to see you again.", login.returnLoginStatus(true));
    }

    @Test
    public void loginFailed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrong"));
        assertFalse(new Login().loginUser("kyl_1", "x")); // nobody registered
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus(false));
    }

    @Test
    public void usernameCheck() {
        assertTrue(login.checkUserName("kyl_1"));
        assertFalse(login.checkUserName("kyle!!!!!!!"));
        assertFalse(login.checkUserName("kyle1"));
        assertFalse(login.checkUserName(null));
    }

    @Test
    public void passwordCheck() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(login.checkPasswordComplexity("password"));
        assertFalse(login.checkPasswordComplexity("Short1!"));
        assertFalse(login.checkPasswordComplexity(null));
    }

    @Test
    public void cellCheck() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
        assertFalse(login.checkCellPhoneNumber("08966553"));
        assertFalse(login.checkCellPhoneNumber("+2783896897612345"));
        assertFalse(login.checkCellPhoneNumber(null));
    }

    @Test
    public void registerUserReportsFirstProblem() {
        assertTrue(login.registerUser("kyle1", "Ch&&sec@ke99!", "+27838968976").startsWith("Username is not"));
        assertTrue(login.registerUser("kyl_1", "password", "+27838968976").startsWith("Password is not"));
        assertTrue(login.registerUser("kyl_1", "Ch&&sec@ke99!", "0838968976").startsWith("Cell number is"));
        assertEquals("User has been registered successfully.", login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976"));
    }
}
