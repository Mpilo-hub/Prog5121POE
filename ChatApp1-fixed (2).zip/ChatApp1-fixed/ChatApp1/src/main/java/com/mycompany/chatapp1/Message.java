package com.mycompany.chatapp1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A QuickChat message (Part 2).
 */
public class Message {

    public static final String STORE_FILE = "messages.json";
    private static final Random RANDOM = new Random();
    private static final List<Message> STORED = new ArrayList<>();
    private static final List<Message> SENT = new ArrayList<>();

    private final String messageID;
    private final int numMessagesSent;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    public Message(int numMessagesSent, String recipient, String messageText) {
        this(generateMessageID(), numMessagesSent, recipient, messageText);
    }

    /** Allows a fixed ID (used by unit tests). */
    public Message(String messageID, int numMessagesSent, String recipient, String messageText) {
        this.messageID = messageID;
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    private static String generateMessageID() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(RANDOM.nextInt(10));
        }
        return sb.toString();
    }

    public String getMessageID() { return messageID; }
    public int getNumMessagesSent() { return numMessagesSent; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }

    /** Message ID must be no more than ten characters. */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String messageIDStatus() {
        return "Message ID generated: " + messageID;
    }

    /** Recipient must start with an international code and have no more than ten digits after it. */
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+\\d{1,3}\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String checkMessageLength() {
        if (messageText != null && messageText.length() <= 250) {
            return "Message ready to send.";
        }
        int length = messageText == null ? 0 : messageText.length();
        return "Message exceeds 250 characters by " + (length - 250) + "; please reduce the size.";
    }

    /** First two digits of ID : message number : FIRSTWORDLASTWORD, all caps. */
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2 || messageText == null || messageText.isBlank()) {
            return "";
        }
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (messageID.substring(0, 2) + ":" + numMessagesSent + ":" + first + last).toUpperCase();
    }

    /**
     * Applies the user's choice: 1 = send, 2 = disregard, 3 = store.
     * Sent messages are remembered; stored messages are written to the JSON file.
     */
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                SENT.add(this);
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : SENT) {
            sb.append(m.details()).append("\n\n");
        }
        return sb.toString().trim();
    }

    public String details() {
        return "Message ID: " + messageID + "\n"
                + "Message Hash: " + messageHash + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + messageText;
    }

    public static int returnTotalMessages() {
        return SENT.size();
    }

    /** Adds this message to the JSON file (the whole file is rewritten as a JSON array). */
    public void storeMessage() {
        STORED.add(this);
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < STORED.size(); i++) {
            json.append(STORED.get(i).toJson());
            json.append(i < STORED.size() - 1 ? ",\n" : "\n");
        }
        json.append("]\n");
        try {
            Files.writeString(Path.of(STORE_FILE), json.toString(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("Could not write " + STORE_FILE + ": " + e.getMessage());
        }
    }

    public String toJson() {
        return "  {\n"
                + "    \"messageID\": \"" + esc(messageID) + "\",\n"
                + "    \"messageHash\": \"" + esc(messageHash) + "\",\n"
                + "    \"recipient\": \"" + esc(recipient) + "\",\n"
                + "    \"message\": \"" + esc(messageText) + "\"\n"
                + "  }";
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    /** Clears static state (used by unit tests). */
    static void reset() {
        SENT.clear();
        STORED.clear();
    }
}
