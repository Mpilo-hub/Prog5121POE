package com.mycompany.chatapp1;

import javax.swing.JOptionPane;

/**
 * QuickChat: registration, login, then sending messages.
 */
public class ChatApp1 {

    public static void main(String[] args) {
        Login login = register();
        if (login == null) {
            return;
        }
        if (!login(login)) {
            return;
        }
        chat();
    }

    // ---------- Part 1 ----------
    private static Login register() {
        JOptionPane.showMessageDialog(null, "=== QuickChat Registration ===");
        String first = ask("Enter First Name:");
        if (first == null) return null;
        String last = ask("Enter Last Name:");
        if (last == null) return null;
        Login login = new Login(first, last);

        String username;
        do {
            username = ask("Enter Username (must contain '_' and be at most 5 characters):");
            if (username == null) return null;
            JOptionPane.showMessageDialog(null, login.usernameMessage(username));
        } while (!login.checkUserName(username));

        String password;
        do {
            password = ask("Enter Password (8+ characters, capital, number, special character):");
            if (password == null) return null;
            JOptionPane.showMessageDialog(null, login.passwordMessage(password));
        } while (!login.checkPasswordComplexity(password));

        String cell;
        do {
            cell = ask("Enter Cell Number with international code (e.g. +27838968976):");
            if (cell == null) return null;
            JOptionPane.showMessageDialog(null, login.cellMessage(cell));
        } while (!login.checkCellPhoneNumber(cell));

        JOptionPane.showMessageDialog(null, login.registerUser(username, password, cell));
        return login;
    }

    private static boolean login(Login login) {
        JOptionPane.showMessageDialog(null, "=== QuickChat Login ===");
        while (true) {
            String u = ask("Enter Username:");
            if (u == null) return false;
            String p = ask("Enter Password:");
            if (p == null) return false;
            boolean ok = login.loginUser(u, p);
            JOptionPane.showMessageDialog(null, login.returnLoginStatus(ok));
            if (ok) return true;
        }
    }

    // ---------- Part 2 ----------
    private static void chat() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        Integer max = null;
        while (max == null) {
            String s = ask("How many messages do you wish to enter?");
            if (s == null) return;
            try {
                int n = Integer.parseInt(s.trim());
                if (n > 0) max = n;
            } catch (NumberFormatException ignored) {
                // ask again
            }
        }

        int entered = 0;
        boolean running = true;
        while (running) {
            String choice = ask("Choose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            if (choice == null) break;
            switch (choice.trim()) {
                case "1":
                    if (entered >= max) {
                        JOptionPane.showMessageDialog(null, "You have already entered all " + max + " messages.");
                    } else {
                        entered = sendMessages(entered, max);
                    }
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;
                case "3":
                    running = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Please choose 1, 2 or 3.");
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());
    }

    /** Captures messages until the limit is reached; returns how many have been entered in total. */
    private static int sendMessages(int entered, int max) {
        while (entered < max) {
            String recipient;
            while (true) {
                recipient = ask("Message " + (entered + 1) + " of " + max + "\nRecipient cell number (e.g. +27718693002):");
                if (recipient == null) return entered;
                String r = new Message(0, recipient, "x").checkRecipientCell();
                JOptionPane.showMessageDialog(null, r);
                if (r.startsWith("Cell phone number successfully")) break;
            }

            String text;
            while (true) {
                text = ask("Enter your message (max 250 characters):");
                if (text == null) return entered;
                if (text.length() <= 250) {
                    JOptionPane.showMessageDialog(null, "Message ready to send.");
                    break;
                }
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
            }

            Message m = new Message(Message.returnTotalMessages(), recipient, text);
            JOptionPane.showMessageDialog(null, m.messageIDStatus());

            int action = 0;
            while (action < 1 || action > 3) {
                String a = ask("Select an option:\n1) Send Message\n2) Disregard Message\n3) Store Message to send later");
                if (a == null) { action = 2; break; }
                try { action = Integer.parseInt(a.trim()); } catch (NumberFormatException e) { action = 0; }
            }

            if (action == 2) {
                String zero;
                do {
                    zero = ask(m.SentMessage(2));
                } while (zero != null && !zero.trim().equals("0"));
                JOptionPane.showMessageDialog(null, "Message deleted.");
            } else {
                JOptionPane.showMessageDialog(null, m.SentMessage(action));
                if (action == 1) {
                    JOptionPane.showMessageDialog(null, m.details());
                }
            }
            entered++;
        }
        return entered;
    }

    private static String ask(String prompt) {
        return JOptionPane.showInputDialog(null, prompt);
    }
}
