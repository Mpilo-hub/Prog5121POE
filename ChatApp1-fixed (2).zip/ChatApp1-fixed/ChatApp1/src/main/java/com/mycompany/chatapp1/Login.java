package com.mycompany.chatapp1;

/**
 * Handles registration and login for QuickChat (Part 1).
 */
public class Login {

    // International code (+ and 1-3 digits) followed by a number of at most ten digits.
    // Pattern approach adapted from standard Java regex usage:
    // Oracle (2024) java.util.regex.Pattern documentation. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/regex/Pattern.html
    private static final String CELL_REGEX = "^\\+\\d{1,3}\\d{1,10}$";

    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    public Login() {
    }

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    /** Username must contain an underscore and be no more than five characters long. */
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    /** Password: at least eight characters, a capital letter, a number and a special character. */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean capital = false, number = false, special = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                capital = true;
            } else if (Character.isDigit(c)) {
                number = true;
            } else if (!Character.isLetterOrDigit(c)) {
                special = true;
            }
        }
        return capital && number && special;
    }

    /** Cell number must start with an international code (+xx) and have no more than ten digits after it. */
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber != null && cellNumber.matches(CELL_REGEX);
    }

    public String registerUser(String username, String password, String cellNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        return "User has been registered successfully.";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username != null && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    public String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    // Messages shown while capturing each field.
    public String usernameMessage(String u) {
        return checkUserName(u) ? "Username successfully captured."
                : "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
    }

    public String passwordMessage(String p) {
        return checkPasswordComplexity(p) ? "Password successfully captured."
                : "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
    }

    public String cellMessage(String c) {
        return checkCellPhoneNumber(c) ? "Cell number successfully captured."
                : "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
    }
}
